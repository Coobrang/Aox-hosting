// var d = new Date();
// var date = d.getDate();
// var year = d.getFullYear();
// var month = d.getMonth();
// var monthArr = ["January", "February","March", "April", "May", "June", "July", "August", "September", "October", "November","December"];
// month = monthArr[month];

// document.getElementById("date-time").innerHTML=month+" "+date+", "+year;

// Mobile Menu

'use strict';

const elemToggleFunc = function (elem){
    elem.classList.toggle("active");
}

const navbar = document.querySelector("[data-nav]");
const navOpenBtn = document.querySelector("[data-nav-open-btn]");
const navCloseBtn = document.querySelector("[data-nav-close-btn]");
const overlay = document.querySelector("[data-overlay]");

const navElemArr = [navOpenBtn, navCloseBtn, overlay];

for (let i = 0; i < navElemArr.length; i++){

    navElemArr[i].addEventListener("click", function(){
        elemToggleFunc(navbar);
        elemToggleFunc(overlay);
        elemToggleFunc(document.body);
    })
}

// Sticky Blur Header
document.addEventListener("DOMContentLoaded", function(){
    var header = document.querySelector(".header");
    var container = document.querySelector(".header .container");


    checkScroll();
    window.addEventListener("resize", checkScroll);

    window.addEventListener("scroll", function(){
        checkScroll();
    });

    function checkScroll() {
        var scrollPosition = window.pageXOffset || document.documentElement.scrollTop;

        var scrollThreshold = 100;

        var windowWidth = window.innerWidth || document.documentElement.clientWidth;
        var isWideScreen = windowWidth > 768;

        if (isWideScreen && scrollPosition > scrollThreshold) {
            header.classList.add("fixed");
        }else{
            header.classList.remove("fixed");
        }
    }
});

// Care OF
var acc = document.getElementsByClassName("btn");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].addEventListener("click", function(){
        this.classList.toggle("active");
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
            panel.style.display = "none";
        }else{
            panel.style.display = "block";
        }
    });
}